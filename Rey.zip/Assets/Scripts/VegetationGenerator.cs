//using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VegetationGenerator : MonoBehaviour
{
    public List<GameObject> vegetationPrefabs = new List<GameObject>();

    private List<GameObject> instances = new List<GameObject>();

    public List<Collider> restrictedBounds = new List<Collider>();

    public int numObjects = 30;

    public Vector3 vegetationBoundsMin = new Vector3(-30, 0, -30);

    public Vector3 vegetationBoundsMax = new Vector3(30, 0, 30);

    public bool reset = false;

    public Transform Vegetation;

    public float randx, randy, randz;

    public Vector3 newPlace, newAngle, newPlaceAgain;


    public GameObject my_vegetaion_object, new_vegetatoin_object;
    Collider m_Collider, m_Collider2;
    Collider house;

    // 1.3 experiments:
    //[Serializable]
    // public struct VegetRand
    // {
    //     public GameObject nameOfPrefab;
    //     public int numOfPrefab;
    // }
    // [SerializeField]
    // private VegetRand stats;

    // Start is called before the first frame update
    void Start()
    {
        GenerateVegetation();
    }

    // Update is called once per frame
    void Update()
    {
        // TODO: Exercise 1.2 -> 3.) 
        // check & handle "reset" to regenerate vegetation instances
        if (reset != false) {
            ClearVegetation();
            GenerateVegetation();
            reset = false;
        }
    }

    void ClearVegetation()
    {
        // TODO: part of Exercise 1.2 -> 3.)  
        for (int i = 0; i < instances.Count; i++) //
        {
            Destroy(instances[i]);
        }
        instances.Clear();
    }

    void GenerateVegetation()
    {
        // TODO: Exercise 1.2 -> 1.)
        // Instantiate & transform random "vegetationPrefab"
        //Vegetation = Transform.Instantiate();
        for (int i = 0; i <= numObjects; i++)
        {
            int veg = UnityEngine.Random.Range(0, 13);
           // Instantiate(vegetationPrefabs[veg]);

            GameObject cld = Instantiate(vegetationPrefabs[veg]);
            cld.transform.SetParent(transform, false);
            
            randx = Random.Range(vegetationBoundsMin.x, vegetationBoundsMax.x);
            randz = Random.Range(vegetationBoundsMin.z, vegetationBoundsMax.z);
            randy = Random.Range(0, 170);
            newPlace = new Vector3(randx, 0, randz);
            newAngle = new Vector3(0, randy, 0);

            cld.transform.eulerAngles = new Vector3(
                cld.transform.eulerAngles.x,
                cld.transform.eulerAngles.y + randy,
                cld.transform.eulerAngles.z
            );
            cld.transform.position = newPlace;

            if (!instances.Contains(cld))
                instances.Add(cld);
        }
        // Collisions need to be resolved at a later time,
        // because Unity physics loop (Unity-internal evaluation of collisions)
        // runs separate from Update() loop
        StartCoroutine(ResolveCollisions());
    }

    IEnumerator ResolveCollisions()
    {
        yield return new WaitForSeconds(2);
        bool resolveAgain = false;

        // TODO: Exercise 1.2 -> 2.)
        // check & handle bounds intersection of each instance with "restrictedBounds"
        
        house = GameObject.Find("House").GetComponent<BoxCollider>(); // there exist a tag, attached to House, called "House"
        newPlaceAgain = new Vector3(randx, 0, randz);
        // your code here
        for (int i = 0; i < instances.Count; i++) //
        {
            m_Collider = instances[i].GetComponent<Collider>();
            if (m_Collider.bounds.Intersects(house.bounds))
            {
                instances[i].transform.Translate(newPlaceAgain);
            } 
        }

        // resolve again (delayed), after new random transform applied to colliding instances
        if (resolveAgain)
            StartCoroutine(ResolveCollisions());
    }

    bool IsInRestrictedBounds(Collider co)
    {
        // TODO: part of Exercise 1.2-> 2.)
        return true;
    }
}